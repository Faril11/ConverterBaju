package org.d3if0006.converterbaju.model

import androidx.annotation.DrawableRes

data class Profile(
    val nama:String,
    @DrawableRes val imageRes: Int
)
